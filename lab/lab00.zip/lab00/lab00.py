def twenty_sixteen():
    """Come up with the most creative expression that evaluates to 2016,
    using only numbers and the +, *, and - operators.

    >>> twenty_sixteen()
    2016
    """
    return ______
